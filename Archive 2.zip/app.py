from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import json
from datetime import datetime
import librosa
import glob

app = Flask(__name__)

# Configuration
DATA_FOLDER = 'data'
ANNOTATIONS_FILE = 'annotations.json'

# Ensure data folder exists
os.makedirs(DATA_FOLDER, exist_ok=True)

# Load existing annotations
def load_annotations():
    if os.path.exists(ANNOTATIONS_FILE):
        with open(ANNOTATIONS_FILE, 'r') as f:
            return json.load(f)
    return []

# Save annotations
def save_annotation(data):
    annotations = load_annotations()
    data['timestamp'] = datetime.now().isoformat()
    annotations.append(data)
    
    with open(ANNOTATIONS_FILE, 'w') as f:
        json.dump(annotations, f, indent=2)
    
    return data

@app.route('/')
def index():
    print("✓ Serving index page")
    return render_template('index.html')

@app.route('/api/files')
def list_files():
    """List all WAV files in data folder"""
    wav_files = glob.glob(os.path.join(DATA_FOLDER, '*.wav'))
    files = [os.path.basename(f) for f in wav_files]
    print(f"✓ Found {len(files)} WAV files: {files}")
    return jsonify(files)

@app.route('/api/info/<filename>')
def get_file_info(filename):
    """Get audio file info"""
    print(f"\n--- Getting info for: {filename} ---")
    
    filepath = os.path.join(DATA_FOLDER, filename)
    print(f"  File path: {filepath}")
    
    if not os.path.exists(filepath):
        print(f"  ERROR: File not found!")
        return jsonify({'error': 'File not found'}), 404
    
    # Load audio file
    print(f"  Loading audio file...")
    y, sr = librosa.load(filepath, sr=None)
    duration = len(y) / sr
    print(f"  Audio duration: {duration:.2f}s, Sample rate: {sr}")
    
    # Check for corresponding text file
    txt_file = filepath.replace('.wav', '.txt')
    print(f"  Looking for text file: {txt_file}")
    
    text_content = ""
    if os.path.exists(txt_file):
        print(f"  ✓ Text file found!")
        with open(txt_file, 'r', encoding='utf-8') as f:
            text_content = f.read().strip()
        print(f"  Text content: '{text_content}'")
        print(f"  Text length: {len(text_content)} characters")
    else:
        print(f"  ✗ No text file found at: {txt_file}")
    
    response = {
        'filename': filename,
        'duration': duration,
        'sample_rate': sr,
        'samples': len(y),
        'text': text_content
    }
    print(f"  Response: {response}")
    print(f"--- Done ---\n")
    
    return jsonify(response)

@app.route('/audio/<filename>')
def serve_audio(filename):
    """Serve audio file from data folder"""
    print(f"Serving audio: {filename}")
    return send_from_directory(DATA_FOLDER, filename)

@app.route('/annotate', methods=['POST'])
def annotate():
    data = request.json
    print(f"Received annotation: {data}")
    
    required = ['filename', 'start', 'end', 'label']
    if not all(field in data for field in required):
        print(f"Missing required fields!")
        return jsonify({'error': 'Missing required fields'}), 400
    
    saved = save_annotation(data)
    print(f"Annotation saved: {saved}")
    return jsonify({'message': 'Annotation saved', 'annotation': saved})

@app.route('/annotations', methods=['GET'])
def get_annotations():
    annotations = load_annotations()
    print(f"Returning {len(annotations)} annotations")
    return jsonify(annotations)

@app.route('/annotations/<filename>', methods=['GET'])
def get_file_annotations(filename):
    """Get annotations for specific file"""
    all_ann = load_annotations()
    file_ann = [a for a in all_ann if a.get('filename') == filename]
    print(f"Returning {len(file_ann)} annotations for {filename}")
    return jsonify(file_ann)

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Starting WAV Annotation Server")
    print("=" * 50)
    print(f"Data folder: {os.path.abspath(DATA_FOLDER)}")
    print(f"Annotations file: {ANNOTATIONS_FILE}")
    print("\nAvailable WAV files:")
    wavs = glob.glob(os.path.join(DATA_FOLDER, '*.wav'))
    for w in wavs:
        txt = w.replace('.wav', '.txt')
        txt_status = "✓ has text" if os.path.exists(txt) else "✗ no text"
        print(f"  • {os.path.basename(w)} - {txt_status}")
    print("\n" + "=" * 50)
    
    app.run(debug=True, port=5000, host='0.0.0.0')