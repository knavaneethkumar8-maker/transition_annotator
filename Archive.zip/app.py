from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import json
from datetime import datetime
import librosa
import glob

app = Flask(__name__)

# Configuration
DATA_FOLDER = 'data'
ANNOTATIONS_FILE = 'annotations.json'

# Ensure data folder exists
os.makedirs(DATA_FOLDER, exist_ok=True)

# Load existing annotations
def load_annotations():
    if os.path.exists(ANNOTATIONS_FILE):
        with open(ANNOTATIONS_FILE, 'r') as f:
            return json.load(f)
    return []

# Save annotations
def save_annotation(data):
    annotations = load_annotations()
    data['timestamp'] = datetime.now().isoformat()
    annotations.append(data)
    
    with open(ANNOTATIONS_FILE, 'w') as f:
        json.dump(annotations, f, indent=2)
    
    return data

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/files')
def list_files():
    """List all WAV files in data folder"""
    wav_files = glob.glob(os.path.join(DATA_FOLDER, '*.wav'))
    files = [os.path.basename(f) for f in wav_files]
    return jsonify(files)

@app.route('/api/info/<filename>')
def get_file_info(filename):
    """Get audio file info"""
    filepath = os.path.join(DATA_FOLDER, filename)
    if not os.path.exists(filepath):
        return jsonify({'error': 'File not found'}), 404
    
    y, sr = librosa.load(filepath, sr=None)
    duration = len(y) / sr
    
    # Check for corresponding text file
    txt_file = filepath.replace('.wav', '.txt')
    text_content = ""
    if os.path.exists(txt_file):
        with open(txt_file, 'r', encoding='utf-8') as f:
            text_content = f.read().strip()
    
    return jsonify({
        'filename': filename,
        'duration': duration,
        'sample_rate': sr,
        'samples': len(y),
        'text': text_content
    })

@app.route('/audio/<filename>')
def serve_audio(filename):
    """Serve audio file from data folder"""
    return send_from_directory(DATA_FOLDER, filename)

@app.route('/annotate', methods=['POST'])
def annotate():
    data = request.json
    
    required = ['filename', 'start', 'end', 'label']
    if not all(field in data for field in required):
        return jsonify({'error': 'Missing required fields'}), 400
    
    saved = save_annotation(data)
    return jsonify({'message': 'Annotation saved', 'annotation': saved})

@app.route('/annotations', methods=['GET'])
def get_annotations():
    return jsonify(load_annotations())

@app.route('/annotations/<filename>', methods=['GET'])
def get_file_annotations(filename):
    """Get annotations for specific file"""
    all_ann = load_annotations()
    file_ann = [a for a in all_ann if a.get('filename') == filename]
    return jsonify(file_ann)

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')